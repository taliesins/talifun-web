using System;
using CodeProject.Downloader;
namespace Downloader
{
    class TestDownload
    {
        static void Main(string[] args)
        {
            FileDownloader downloader = new FileDownloader();
            downloader.DownloadComplete += new EventHandler(downloader_DownloadedComplete);
            downloader.ProgressChanged += new DownloadProgressHandler(downloader_ProgressChanged);
            downloader.Download("http://localhost:3691/Static/test.wmv");
        }

        static void downloader_ProgressChanged(object sender, DownloadEventArgs e)
        {
            Console.WriteLine("Progress " + e.PercentDone);
        }

        static void downloader_DownloadedComplete(object sender, EventArgs e)
        {
            System.Console.WriteLine("Download complete.");
        }
    }
}
